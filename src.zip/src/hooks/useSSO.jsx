// src/hooks/useSSO.jsx
import { useState } from 'react';
import form from 'form-urlencoded';

export function useSSO() {
  const [userInfo, setUserInfo] = useState(null);

  // Let op: Deze gegevens (CLIENT_SECRET) zijn onveilig in productie.
  const CLIENT_ID = "82d99688-d922-4bfc-8d2d-e2871eb05ebd";
  const CLIENT_SECRET = "YHW8Q~-iictXaRYBw~PV5U_9lF_.bCS1KLUMsc.W";
  const TENANT_ID = "82022306-deb0-41be-94c4-763bf46d3547";

  /**
   * 1. Probeer eerst SSO-token via on-behalf-of flow
   */
  async function fetchGraphToken() {
    try {
      // Vraag Office SSO-token op
      const ssoToken = await Office.auth.getAccessToken({
        allowSignInPrompt: true,
        allowConsentPrompt: true,
        forMSGraphAccess: true
      });

      // On-behalf-of flow: ruil ssoToken in voor een Graph-token
      const [, assertion] = `Bearer ${ssoToken}`.split(" ");
      const formParams = {
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
        assertion: assertion,
        requested_token_use: "on_behalf_of",
        scope: "https://graph.microsoft.com/User.Read",
      };

      const stsDomain = "https://login.microsoftonline.com";
      const tokenURLSegment = "oauth2/v2.0/token";
      const encodedForm = form(formParams);

      const tokenResponse = await fetch(`${stsDomain}/${TENANT_ID}/${tokenURLSegment}`, {
        method: "POST",
        body: encodedForm,
        headers: {
          Accept: "application/json",
          "Content-Type": "application/x-www-form-urlencoded",
        },
      });

      const json = await tokenResponse.json();
      if (json.error) {
        throw new Error(`Token request failed: ${json.error_description}`);
      }
      return json.access_token;
    } catch (error) {
      console.error("Error in fetchGraphToken (SSO):", error);
      throw error;
    }
  }

  /**
   * 2. FallbackAuth: open Office-dialog met MSAL-login als SSO faalt
   */
  async function fallbackAuth() {
    return new Promise((resolve, reject) => {
      const url = "/fallbackauthdialog.html"; 
      const fullUrl = location.protocol + "//" + location.hostname + (location.port ? ":" + location.port : "") + url;

      Office.context.ui.displayDialogAsync(fullUrl, { height: 60, width: 30 }, function (asyncResult) {
        if (asyncResult.status === Office.AsyncResultStatus.Failed) {
          reject(asyncResult.error);
          return;
        }
        const loginDialog = asyncResult.value;
        loginDialog.addEventHandler(Office.EventType.DialogMessageReceived, (arg) => {
          const messageFromDialog = JSON.parse(arg.message);
          if (messageFromDialog.status === "success") {
            // Gelukt: we hebben een Graph-token
            loginDialog.close();
            const token = messageFromDialog.result;
            resolve(token);
          } else {
            loginDialog.close();
            reject(messageFromDialog.error || messageFromDialog.result);
          }
        });
      });
    });
  }

  /**
   * 3. Ophalen van gebruikersinfo
   *    - Probeer eerst SSO
   *    - Als dat faalt => fallback
   */
  async function getUserInfo() {
    try {
      // Probeer SSO-token op te halen en userinfo van Graph
      const graphToken = await fetchGraphToken();
      const data = await getUserFromGraph(graphToken);
      setUserInfo(data);
      return data;
    } catch (error) {
      console.warn("SSO mislukt, probeer fallback:", error);

      // Fallback in Office-dialog met MSAL
      try {
        const fallbackToken = await fallbackAuth();
        const data = await getUserFromGraph(fallbackToken);
        setUserInfo(data);
        return data;
      } catch (fallbackError) {
        console.error("Fallback ook mislukt:", fallbackError);
        throw fallbackError;
      }
    }
  }

  /**
   * 4. Hulpfunctie: Graph /me endpoint
   */
  async function getUserFromGraph(token) {
    const response = await fetch('https://graph.microsoft.com/v1.0/me', {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (!response.ok) {
      throw new Error("Fout bij ophalen van gebruikersinformatie (Graph /me)");
    }
    return response.json();
  }

  return { userInfo, getUserInfo };
}
